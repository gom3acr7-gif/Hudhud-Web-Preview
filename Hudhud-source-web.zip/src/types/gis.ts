export type LandUseType = 
  | 'سكني'
  | 'تجاري'
  | 'تعليمي'
  | 'حدائق ومرافق'
  | 'استثماري'
  | 'حكومي'
  | 'صناعي خفيف';

export type ParcelStatus = 
  | 'معتمد ومفرغ'
  | 'قيد التحديث'
  | 'مرخص للبناء'
  | 'أرض فضاء'
  | 'مشروع قيد التنفيذ';

export interface LatLng {
  lat: number;
  lng: number;
}

export interface Parcel {
  id: string;
  parcelNumber: string;        // رقم قطعة الأرض
  planNumber: string;          // رقم المخطط التنظيمي
  planName: string;            // اسم المخطط
  landUse: LandUseType;        // نوع الاستخدام
  areaSquareMeters: number;    // المساحة بالمتر المربع
  status: ParcelStatus;        // حالة الاعتماد والترخيص
  coordinates: LatLng;         // مركز القطعة
  boundaries?: [number, number][]; // مضلع حدود القطعة (Polygon)
  dimensions?: {
    north: number;
    south: number;
    east: number;
    west: number;
  };
  zoningDetails?: {
    buildingPercentage: number; // نسبة البناء
    floorsAllowed: number;      // عدد الأدوار المسموح
    setbacks: string;           // الارتدادات
  };
  updatedAt: string;
  source: string;
  isDemoRecord: true;          // تأكيد كونها بيانات تجريبية
}

export interface SubdivisionPlan {
  id: string;
  planNumber: string;
  planName: string;
  city: string;
  district: string;
  totalParcels: number;
  approvalYear: number;
  center: LatLng;
  bounds: [[number, number], [number, number]];
  isDemoRecord: true;
}

export type ServiceCategory = 
  | 'hospitals'      // مستشفيات ومراكز صحية
  | 'schools'        // مدارس ومؤسسات تعليمية
  | 'mosques'        // مساجد وجوامع
  | 'government'     // مكاتب وجهات حكومية
  | 'fuel'           // محطات وقود
  | 'cultural'       // مواقع ثقافية وترفيهية
  | 'parks';         // حدائق ومنتزهات

export interface PublicService {
  id: string;
  name: string;
  category: ServiceCategory;
  categoryLabelAr: string;
  address: string;
  city: string;
  coordinates: LatLng;
  phone?: string;
  workingHours?: string;
  rating?: number;
  distanceKm?: number;
  isDemoRecord: true;
}

export interface GeoReport {
  id: string;
  category: 
    | 'تعديات على أراضي عامة'
    | 'صيانة طرق ومرافق'
    | 'نقص لوحات إرشادية'
    | 'تصريف سيول ومياه أمطار'
    | 'نظافة وتراكم مخلفات'
    | 'أخرى';
  description: string;
  coordinates: LatLng;
  photoUrl?: string;
  status: 'draft_local' | 'synced_backend';
  createdAt: string;
  addressApprox?: string;
}

export interface FavoriteItem {
  id: string;
  type: 'parcel' | 'service' | 'plan';
  title: string;
  subtitle: string;
  coordinates: LatLng;
  savedAt: string;
  data: Parcel | PublicService | SubdivisionPlan;
}

export type MapTileLayerType = 'streets' | 'satellite' | 'topo';
