import { FavoriteItem, GeoReport } from '../types/gis';

const FAVORITES_KEY = 'hudhud_favorites_v1';
const DRAFTS_KEY = 'hudhud_draft_reports_v1';
const SETTINGS_KEY = 'hudhud_app_settings_v1';

export interface AppSettings {
  allowLocation: boolean;
  mapLayer: 'streets' | 'satellite' | 'topo';
  showParcels: boolean;
  showServices: boolean;
  showPlans: boolean;
}

const DEFAULT_SETTINGS: AppSettings = {
  allowLocation: true,
  mapLayer: 'streets',
  showParcels: true,
  showServices: true,
  showPlans: true,
};

export const storage = {
  getFavorites(): FavoriteItem[] {
    try {
      const data = localStorage.getItem(FAVORITES_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addFavorite(item: FavoriteItem): void {
    const list = this.getFavorites().filter((f) => f.id !== item.id);
    list.unshift(item);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(list));
  },

  removeFavorite(id: string): void {
    const list = this.getFavorites().filter((f) => f.id !== id);
    localStorage.setItem(FAVORITES_KEY, JSON.stringify(list));
  },

  isFavorite(id: string): boolean {
    return this.getFavorites().some((f) => f.id === id);
  },

  getDraftReports(): GeoReport[] {
    try {
      const data = localStorage.getItem(DRAFTS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  saveDraftReport(report: GeoReport): void {
    const drafts = this.getDraftReports().filter((d) => d.id !== report.id);
    drafts.unshift(report);
    localStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts));
  },

  deleteDraftReport(id: string): void {
    const drafts = this.getDraftReports().filter((d) => d.id !== id);
    localStorage.setItem(DRAFTS_KEY, JSON.stringify(drafts));
  },

  getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      return data ? { ...DEFAULT_SETTINGS, ...JSON.parse(data) } : DEFAULT_SETTINGS;
    } catch {
      return DEFAULT_SETTINGS;
    }
  },

  saveSettings(settings: Partial<AppSettings>): AppSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
    return updated;
  },
};
