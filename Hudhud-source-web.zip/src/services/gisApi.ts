/**
 * Hudhud GIS API Integration Layer
 */

import { DEMO_PARCELS, DEMO_PLANS, DEMO_PUBLIC_SERVICES } from '../data/mockGisData';
import { Parcel, SubdivisionPlan, PublicService, GeoReport, LatLng, ServiceCategory } from '../types/gis';
import { storage } from './storage';

export interface ViewportBBox {
  minLat: number;
  maxLat: number;
  minLng: number;
  maxLng: number;
}

export interface GisApiConfig {
  backendUrl: string | null;
  isBackendConnected: boolean;
  version: string;
}

class GisApiService {
  private config: GisApiConfig = {
    backendUrl: null,
    isBackendConnected: false,
    version: '1.0.0-offline-preview',
  };

  public getStatus(): GisApiConfig {
    return { ...this.config };
  }

  public async searchParcels(query: string): Promise<Parcel[]> {
    const trimmed = query.trim().toLowerCase();
    if (!trimmed) return DEMO_PARCELS;

    return DEMO_PARCELS.filter(
      (p) =>
        p.parcelNumber.toLowerCase().includes(trimmed) ||
        p.planNumber.toLowerCase().includes(trimmed) ||
        p.planName.toLowerCase().includes(trimmed) ||
        p.landUse.toLowerCase().includes(trimmed)
    );
  }

  public async getParcelsInBounds(bbox: ViewportBBox): Promise<Parcel[]> {
    return DEMO_PARCELS.filter((p) => {
      const lat = p.coordinates.lat;
      const lng = p.coordinates.lng;
      return lat >= bbox.minLat && lat <= bbox.maxLat && lng >= bbox.minLng && lng <= bbox.maxLng;
    });
  }

  public async searchPlans(query: string): Promise<SubdivisionPlan[]> {
    const trimmed = query.trim().toLowerCase();
    if (!trimmed) return DEMO_PLANS;

    return DEMO_PLANS.filter(
      (pl) =>
        pl.planNumber.toLowerCase().includes(trimmed) ||
        pl.planName.toLowerCase().includes(trimmed) ||
        pl.district.toLowerCase().includes(trimmed)
    );
  }

  public async getNearbyServices(
    userLocation?: LatLng,
    category?: ServiceCategory | 'all',
    searchQuery?: string
  ): Promise<PublicService[]> {
    let results = [...DEMO_PUBLIC_SERVICES];

    if (category && category !== 'all') {
      results = results.filter((s) => s.category === category);
    }

    if (searchQuery && searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      results = results.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.address.toLowerCase().includes(q) ||
          s.categoryLabelAr.toLowerCase().includes(q)
      );
    }

    if (userLocation) {
      results = results.map((service) => ({
        ...service,
        distanceKm: calculateDistanceKm(
          userLocation.lat,
          userLocation.lng,
          service.coordinates.lat,
          service.coordinates.lng
        ),
      }));

      results.sort((a, b) => (a.distanceKm ?? 0) - (b.distanceKm ?? 0));
    }

    return results;
  }

  public async submitGeoReport(
    reportData: Omit<GeoReport, 'id' | 'status' | 'createdAt'>
  ): Promise<{ success: boolean; report: GeoReport; messageAr: string }> {
    const newReport: GeoReport = {
      ...reportData,
      id: `report-${Date.now()}`,
      status: 'draft_local',
      createdAt: new Date().toISOString(),
    };

    storage.saveDraftReport(newReport);

    return {
      success: true,
      report: newReport,
      messageAr: 'تم حفظ البلاغ محلياً كمسودة ميدانية على جهازك بنجاح.',
    };
  }
}

export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c;
  return Math.round(d * 10) / 10;
}

export const gisApi = new GisApiService();
