import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { BottomNav, NavTab } from './components/BottomNav';
import { InteractiveMap } from './components/InteractiveMap';
import { ParcelDetailModal } from './components/ParcelDetailModal';
import { SearchModal } from './components/SearchModal';
import { ServicesView } from './components/ServicesView';
import { ReportsView } from './components/ReportsView';
import { FavoritesView } from './components/FavoritesView';
import { SettingsView } from './components/SettingsView';
import { SplashScreen } from './components/SplashScreen';
import { Parcel, PublicService, SubdivisionPlan, LatLng } from './types/gis';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [activeTab, setActiveTab] = useState<NavTab>('map');
  const [showSettings, setShowSettings] = useState(false);
  const [selectedParcel, setSelectedParcel] = useState<Parcel | null>(null);
  const [targetLocation, setTargetLocation] = useState<LatLng | null>(null);
  const [userLocation, setUserLocation] = useState<LatLng | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2200);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.log('Location not granted or unavailable:', error.message);
        },
        { enableHighAccuracy: true, timeout: 8000 }
      );
    }
  }, []);

  const handleSelectParcel = (parcel: Parcel) => {
    setSelectedParcel(parcel);
    setTargetLocation(parcel.coordinates);
  };

  const handleSelectPlan = (plan: SubdivisionPlan) => {
    setTargetLocation(plan.center);
    setActiveTab('map');
    setShowSettings(false);
  };

  const handleSelectService = (service: PublicService) => {
    setTargetLocation(service.coordinates);
    setActiveTab('map');
    setShowSettings(false);
  };

  const handleShowCoordsOnMap = (coords: LatLng) => {
    setTargetLocation(coords);
    setActiveTab('map');
    setShowSettings(false);
  };

  const handleResetData = () => {
    localStorage.removeItem('hudhud_favorites_v1');
    localStorage.removeItem('hudhud_draft_reports_v1');
    localStorage.removeItem('hudhud_app_settings_v1');
    alert('تمت إعادة ضبط البيانات المحلية بنجاح');
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans select-none antialiased">
      {showSplash && <SplashScreen onDismiss={() => setShowSplash(false)} />}

      <Header
        onOpenSettings={() => setShowSettings(!showSettings)}
        onOpenSearch={() => {
          setShowSettings(false);
          setActiveTab('search');
        }}
      />

      <main className="flex-1 pb-16 overflow-y-auto">
        {showSettings ? (
          <SettingsView onResetData={handleResetData} />
        ) : (
          <>
            {activeTab === 'map' && (
              <InteractiveMap
                selectedParcel={selectedParcel}
                onSelectParcel={handleSelectParcel}
                onSelectService={handleSelectService}
                targetLocation={targetLocation}
              />
            )}

            {activeTab === 'search' && (
              <SearchModal
                onSelectParcel={(parcel) => {
                  handleSelectParcel(parcel);
                  setActiveTab('map');
                }}
                onSelectService={handleSelectService}
                onSelectPlan={handleSelectPlan}
              />
            )}

            {activeTab === 'services' && (
              <ServicesView
                onShowOnMap={handleSelectService}
                userLocation={userLocation}
              />
            )}

            {activeTab === 'reports' && (
              <ReportsView userLocation={userLocation} />
            )}

            {activeTab === 'favorites' && (
              <FavoritesView
                onSelectParcel={(p) => {
                  handleSelectParcel(p);
                  setActiveTab('map');
                }}
                onSelectService={handleSelectService}
                onShowOnMap={handleShowCoordsOnMap}
              />
            )}
          </>
        )}
      </main>

      <BottomNav
        activeTab={showSettings ? ('map' as NavTab) : activeTab}
        onTabChange={(tab) => {
          setShowSettings(false);
          setActiveTab(tab);
        }}
      />

      <ParcelDetailModal
        parcel={selectedParcel}
        onClose={() => setSelectedParcel(null)}
      />
    </div>
  );
}
