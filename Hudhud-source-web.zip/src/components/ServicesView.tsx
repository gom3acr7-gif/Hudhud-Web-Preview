import React, { useState, useEffect } from 'react';
import {
  Building2,
  Navigation,
  Phone,
  Clock,
  MapPin,
  Bookmark,
  Share2,
  Check,
  Compass,
} from 'lucide-react';
import { PublicService, ServiceCategory, LatLng } from '../types/gis';
import { gisApi } from '../services/gisApi';
import { storage } from '../services/storage';

interface ServicesViewProps {
  onShowOnMap: (service: PublicService) => void;
  userLocation: LatLng | null;
}

export const ServicesView: React.FC<ServicesViewProps> = ({ onShowOnMap, userLocation }) => {
  const [selectedCategory, setSelectedCategory] = useState<ServiceCategory | 'all'>('all');
  const [services, setServices] = useState<PublicService[]>([]);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories: { id: ServiceCategory | 'all'; label: string; icon: string }[] = [
    { id: 'all', label: 'الكل', icon: '🏛️' },
    { id: 'hospitals', label: 'مستشفيات', icon: '🏥' },
    { id: 'schools', label: 'مدارس', icon: '🏫' },
    { id: 'mosques', label: 'مساجد', icon: '🕌' },
    { id: 'government', label: 'جهات حكومية', icon: '⚖️' },
    { id: 'fuel', label: 'محطات وقود', icon: '⛽' },
    { id: 'cultural', label: 'ثقافة وترفيه', icon: '🎨' },
    { id: 'parks', label: 'حدائق', icon: '🌳' },
  ];

  useEffect(() => {
    gisApi.getNearbyServices(userLocation || undefined, selectedCategory).then((data) => {
      setServices(data);
    });
  }, [selectedCategory, userLocation]);

  const openGoogleMaps = (service: PublicService) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${service.coordinates.lat},${service.coordinates.lng}`;
    window.open(url, '_blank');
  };

  const toggleFavorite = (service: PublicService) => {
    if (storage.isFavorite(service.id)) {
      storage.removeFavorite(service.id);
    } else {
      storage.addFavorite({
        id: service.id,
        type: 'service',
        title: service.name,
        subtitle: `${service.categoryLabelAr} · ${service.city}`,
        coordinates: service.coordinates,
        savedAt: new Date().toISOString(),
        data: service,
      });
    }
    setServices([...services]);
  };

  const handleShare = (service: PublicService) => {
    const text = `${service.name} (${service.categoryLabelAr})\nالعنوان: ${service.address}\nالإحداثيات: ${service.coordinates.lat}, ${service.coordinates.lng}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedId(service.id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  return (
    <div className="w-full max-w-3xl mx-auto p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white font-cairo">
            دليل الخدمات والمرافق البلدية
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            استعراض المنشآت الحيوية مع حساب المسافة الفورية وتوجيه الملاحة
          </p>
        </div>

        {userLocation && (
          <span className="flex items-center gap-1 text-[11px] font-medium text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-1 rounded-lg">
            <Compass className="w-3.5 h-3.5" />
            <span>المسافات مقاسة بدقة GPS</span>
          </span>
        )}
      </div>

      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`min-h-[40px] px-3.5 rounded-xl font-medium flex items-center gap-1.5 transition-all whitespace-nowrap shrink-0 ${
                isActive
                  ? 'bg-[#d96b27] text-white shadow-xs'
                  : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      <div className="space-y-3">
        {services.map((service) => {
          const isFav = storage.isFavorite(service.id);
          return (
            <div
              key={service.id}
              className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs hover:border-[#d96b27]/40 transition-all flex flex-col gap-3"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-xl bg-orange-500/10 text-[#d96b27] flex items-center justify-center font-bold text-lg shrink-0">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white font-cairo">
                      {service.name}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      <span>{service.categoryLabelAr}</span>
                      <span>·</span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-[#d96b27]" />
                        {service.address}
                      </span>
                    </div>
                  </div>
                </div>

                {service.distanceKm !== undefined && (
                  <span className="text-xs font-mono font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2.5 py-1 rounded-xl shrink-0">
                    {service.distanceKm} كم
                  </span>
                )}
              </div>

              {(service.workingHours || service.phone) && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-slate-600 dark:text-slate-300 pt-1 border-t border-slate-100 dark:border-slate-700/50">
                  {service.workingHours && (
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <span className="truncate">{service.workingHours}</span>
                    </div>
                  )}
                  {service.phone && (
                    <div className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      <a
                        href={`tel:${service.phone}`}
                        className="text-[#d96b27] hover:underline font-mono"
                      >
                        {service.phone}
                      </a>
                    </div>
                  )}
                </div>
              )}

              <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-100 dark:border-slate-700/50">
                <button
                  onClick={() => toggleFavorite(service)}
                  className={`min-h-[38px] px-3 rounded-xl text-xs font-medium border flex items-center gap-1.5 transition-colors ${
                    isFav
                      ? 'bg-amber-500 text-white border-amber-600'
                      : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${isFav ? 'fill-white' : ''}`} />
                  <span>{isFav ? 'محفوظ' : 'حفظ'}</span>
                </button>

                <button
                  onClick={() => handleShare(service)}
                  className="min-h-[38px] px-3 rounded-xl text-xs font-medium bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 flex items-center gap-1.5 transition-colors"
                >
                  {copiedId === service.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-500" />
                  ) : (
                    <Share2 className="w-3.5 h-3.5" />
                  )}
                  <span>مشاركة</span>
                </button>

                <button
                  onClick={() => onShowOnMap(service)}
                  className="min-h-[38px] px-3.5 rounded-xl text-xs font-semibold bg-slate-100 dark:bg-slate-700 text-slate-800 dark:text-slate-100 hover:bg-slate-200 flex items-center gap-1.5 transition-colors"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#d96b27]" />
                  <span>عرض بالخريطة</span>
                </button>

                <button
                  onClick={() => openGoogleMaps(service)}
                  className="min-h-[38px] px-3.5 rounded-xl text-xs font-semibold bg-[#d96b27] text-white hover:bg-[#c35a1a] flex items-center gap-1.5 shadow-xs transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  <span>الملاحة</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
