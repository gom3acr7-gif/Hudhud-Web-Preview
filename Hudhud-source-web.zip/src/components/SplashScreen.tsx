import React from 'react';
import { ArrowLeft } from 'lucide-react';

interface SplashScreenProps {
  onDismiss: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onDismiss }) => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-between bg-gradient-to-b from-slate-900 via-[#182338] to-slate-950 text-white p-6 select-none animate-fadeIn">
      {/* Top Header / Skip */}
      <div className="w-full flex justify-between items-center pt-safe">
        <span className="text-xs font-mono tracking-wider text-amber-400/80 bg-amber-950/40 border border-amber-500/20 px-2.5 py-1 rounded-full">
          v1.0.0 · com.hudhud.app
        </span>
        <button
          onClick={onDismiss}
          className="text-xs text-slate-400 hover:text-white transition-colors px-3 py-1.5 rounded-lg border border-slate-700/60"
        >
          تخطي
        </button>
      </div>

      {/* Main Brand Center */}
      <div className="flex flex-col items-center text-center max-w-sm px-4">
        {/* Uploaded Logo Artwork */}
        <div className="relative mb-6 rounded-3xl overflow-hidden shadow-2xl shadow-orange-950/50 border-2 border-amber-500/30 bg-slate-800/40 p-2">
          <img
            src="/assets/aistudio/file_00000000cce081fab0c076663ac3d5ce_d4c551e0.jpg"
            alt="شعار هُدهُد الرسمي"
            className="w-48 h-auto object-cover rounded-2xl"
          />
        </div>

        <h1 className="text-3xl font-extrabold tracking-tight text-white mb-2 font-cairo">
          هُدْهُدْ <span className="text-amber-500">Hudhud</span>
        </h1>
        <p className="text-sm text-slate-300 leading-relaxed max-w-xs mb-4">
          نظام الاستعلام الجغرافي الذكي للأراضي والمخططات التنظيمية والخدمات العامة
        </p>

        <div className="flex items-center gap-2 text-xs text-amber-300/90 bg-amber-500/10 border border-amber-500/20 px-3 py-1.5 rounded-full">
          <span>دعم العمل الميداني دون اتصال (Offline GIS)</span>
        </div>
      </div>

      {/* Bottom Action Area */}
      <div className="w-full max-w-sm pb-safe flex flex-col gap-3">
        <button
          onClick={onDismiss}
          className="w-full h-12 bg-gradient-to-r from-[#d96b27] to-[#e87a38] text-white font-bold rounded-xl shadow-lg shadow-orange-900/40 active:scale-[0.98] transition-all flex items-center justify-center gap-2 text-base"
        >
          <span>ابدأ الاستكشاف</span>
          <ArrowLeft className="w-5 h-5" />
        </button>

        <p className="text-center text-[11px] text-slate-400">
          تطبيق أندرويد متكامل متوافق مع معايير GIS
        </p>
      </div>
    </div>
  );
};
