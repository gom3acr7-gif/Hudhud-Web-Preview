import React from 'react';
import { Settings, WifiOff, Download } from 'lucide-react';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenSettings, onOpenSearch }) => {
  return (
    <header className="sticky top-0 z-30 h-14 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 px-4 flex items-center justify-between gap-4">
      {/* Zone 1: Brand Wordmark & Official Icon */}
      <div className="flex items-center gap-2.5 shrink-0">
        <div className="w-9 h-9 rounded-xl overflow-hidden border border-amber-500/30 shadow-sm shrink-0 bg-slate-100 dark:bg-slate-800">
          <img
            src="/assets/aistudio/file_00000000cce081fab0c076663ac3d5ce_d4c551e0.jpg"
            alt="شعار هدهد"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="flex flex-col">
          <span className="text-base font-extrabold text-slate-900 dark:text-white leading-none font-cairo">
            هُدْهُدْ <span className="text-xs font-semibold text-[#d96b27]">Hudhud</span>
          </span>
          <span className="text-[10px] text-slate-500 dark:text-slate-400 leading-tight">
            نظم المعلومات الجغرافية
          </span>
        </div>
      </div>

      {/* Zone 2: Informative quiet status */}
      <div className="hidden sm:flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
        <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-amber-500/10 text-amber-700 dark:text-amber-300 font-medium text-[11px]">
          <WifiOff className="w-3 h-3" />
          <span>وضع غير متصل · بيانات تجريبية</span>
        </span>
      </div>

      {/* Zone 3: Actions */}
      <div className="flex items-center gap-2 shrink-0">
        <button
          onClick={onOpenSettings}
          className="min-h-[36px] px-3 rounded-xl bg-[#d96b27] hover:bg-[#c35a1a] text-white text-xs font-bold flex items-center gap-1.5 shadow-xs transition-all active:scale-[0.98]"
          title="تثبيت التطبيق وتنزيل الحزمة"
        >
          <Download className="w-3.5 h-3.5" />
          <span>تنزيل / تثبيت</span>
        </button>

        <button
          onClick={onOpenSettings}
          title="الإعدادات وحزمة الأندرويد"
          className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>
    </header>
  );
};
