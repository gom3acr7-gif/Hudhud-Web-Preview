import React, { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import {
  Layers,
  Crosshair,
  Plus,
  Minus,
  Ruler,
  AlertCircle,
} from 'lucide-react';
import { Parcel, PublicService, MapTileLayerType, LatLng } from '../types/gis';
import { DEMO_PARCELS, DEMO_PUBLIC_SERVICES, DEMO_PLANS } from '../data/mockGisData';

interface InteractiveMapProps {
  selectedParcel: Parcel | null;
  onSelectParcel: (parcel: Parcel) => void;
  onSelectService: (service: PublicService) => void;
  targetLocation?: LatLng | null;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  selectedParcel,
  onSelectParcel,
  onSelectService,
  targetLocation,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const tileLayerRef = useRef<L.TileLayer | null>(null);
  const parcelLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const serviceLayerGroupRef = useRef<L.LayerGroup | null>(null);
  const userMarkerRef = useRef<L.CircleMarker | null>(null);
  const measureLineRef = useRef<L.Polyline | null>(null);

  const [activeLayer, setActiveLayer] = useState<MapTileLayerType>('streets');
  const [showLayerDrawer, setShowLayerDrawer] = useState(false);
  const [showParcels, setShowParcels] = useState(true);
  const [showServices, setShowServices] = useState(true);
  const [isLocating, setIsLocating] = useState(false);
  const [measureMode, setMeasureMode] = useState(false);
  const [measurePoints, setMeasurePoints] = useState<[number, number][]>([]);
  const [measureDistance, setMeasureDistance] = useState<number | null>(null);
  const [tileError, setTileError] = useState(false);

  useEffect(() => {
    if (!mapContainerRef.current || mapInstanceRef.current) return;

    const map = L.map(mapContainerRef.current, {
      center: [24.8465, 46.6852],
      zoom: 16,
      zoomControl: false,
    });

    mapInstanceRef.current = map;

    const parcelGroup = L.layerGroup().addTo(map);
    const serviceGroup = L.layerGroup().addTo(map);
    parcelLayerGroupRef.current = parcelGroup;
    serviceLayerGroupRef.current = serviceGroup;

    updateTileLayer(map, 'streets');

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
  }, []);

  const updateTileLayer = (map: L.Map, layerType: MapTileLayerType) => {
    if (tileLayerRef.current) {
      map.removeLayer(tileLayerRef.current);
    }

    setTileError(false);

    let url = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
    let attribution = '&copy; OpenStreetMap contributors';
    let maxZoom = 19;

    if (layerType === 'satellite') {
      url = 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}';
      attribution = 'Tiles &copy; Esri &mdash; Source: Esri, Maxar, Earthstar Geographics';
      maxZoom = 19;
    } else if (layerType === 'topo') {
      url = 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png';
      attribution = '&copy; OpenStreetMap & CARTO';
      maxZoom = 20;
    }

    const tile = L.tileLayer(url, { attribution, maxZoom });

    tile.on('tileerror', () => {
      setTileError(true);
    });

    tile.addTo(map);
    tileLayerRef.current = tile;
  };

  const handleLayerSelect = (type: MapTileLayerType) => {
    setActiveLayer(type);
    if (mapInstanceRef.current) {
      updateTileLayer(mapInstanceRef.current, type);
    }
    setShowLayerDrawer(false);
  };

  useEffect(() => {
    const group = parcelLayerGroupRef.current;
    if (!group) return;

    group.clearLayers();

    if (!showParcels) return;

    DEMO_PARCELS.forEach((parcel) => {
      const isSelected = selectedParcel?.id === parcel.id;
      let fillColor = '#3b82f6';
      if (parcel.landUse === 'تجاري') fillColor = '#d96b27';
      if (parcel.landUse === 'تعليمي') fillColor = '#10b981';
      if (parcel.landUse === 'حدائق ومرافق') fillColor = '#22c55e';
      if (parcel.landUse === 'استثماري') fillColor = '#8b5cf6';

      if (parcel.boundaries && parcel.boundaries.length > 0) {
        const polygon = L.polygon(parcel.boundaries as [number, number][], {
          color: isSelected ? '#1e293b' : fillColor,
          weight: isSelected ? 3 : 2,
          opacity: 1,
          fillColor,
          fillOpacity: isSelected ? 0.65 : 0.35,
          dashArray: isSelected ? undefined : '2, 4',
        });

        polygon.bindTooltip(
          `<div class="text-xs font-bold font-cairo">قطعة: ${parcel.parcelNumber}<br/><span class="text-slate-500 font-normal">${parcel.landUse}</span></div>`,
          { permanent: false, direction: 'center', className: 'bg-white px-2 py-1 rounded shadow text-slate-800' }
        );

        polygon.on('click', () => {
          onSelectParcel(parcel);
        });

        group.addLayer(polygon);
      }
    });
  }, [showParcels, selectedParcel, onSelectParcel]);

  useEffect(() => {
    const group = serviceLayerGroupRef.current;
    if (!group) return;

    group.clearLayers();

    if (!showServices) return;

    DEMO_PUBLIC_SERVICES.forEach((service) => {
      let bg = '#d96b27';
      let iconSymbol = '📍';
      if (service.category === 'hospitals') {
        bg = '#ef4444';
        iconSymbol = '🏥';
      } else if (service.category === 'schools') {
        bg = '#3b82f6';
        iconSymbol = '🏫';
      } else if (service.category === 'mosques') {
        bg = '#10b981';
        iconSymbol = '🕌';
      } else if (service.category === 'fuel') {
        bg = '#f59e0b';
        iconSymbol = '⛽';
      } else if (service.category === 'government') {
        bg = '#64748b';
        iconSymbol = '🏛️';
      } else if (service.category === 'parks') {
        bg = '#22c55e';
        iconSymbol = '🌳';
      }

      const customIcon = L.divIcon({
        className: 'custom-service-marker',
        html: `
          <div style="background-color: ${bg}; width: 34px; height: 34px; border-radius: 9999px; border: 2.5px solid white; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.2); display: flex; align-items: center; justify-content: center; font-size: 15px; cursor: pointer;">
            ${iconSymbol}
          </div>
        `,
        iconSize: [34, 34],
        iconAnchor: [17, 17],
      });

      const marker = L.marker([service.coordinates.lat, service.coordinates.lng], { icon: customIcon });

      marker.on('click', () => {
        onSelectService(service);
      });

      group.addLayer(marker);
    });
  }, [showServices, onSelectService]);

  useEffect(() => {
    if (!targetLocation || !mapInstanceRef.current) return;
    mapInstanceRef.current.flyTo([targetLocation.lat, targetLocation.lng], 18, {
      duration: 1.2,
    });
  }, [targetLocation]);

  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const handleMapClick = (e: L.LeafletMouseEvent) => {
      if (!measureMode) return;

      const newPoint: [number, number] = [e.latlng.lat, e.latlng.lng];
      const updated = [...measurePoints, newPoint];

      if (updated.length > 2) {
        setMeasurePoints([newPoint]);
        setMeasureDistance(null);
        if (measureLineRef.current) {
          map.removeLayer(measureLineRef.current);
          measureLineRef.current = null;
        }
      } else {
        setMeasurePoints(updated);
        if (updated.length === 2) {
          const latlng1 = L.latLng(updated[0][0], updated[0][1]);
          const latlng2 = L.latLng(updated[1][0], updated[1][1]);
          const dist = Math.round(latlng1.distanceTo(latlng2));
          setMeasureDistance(dist);

          if (measureLineRef.current) {
            map.removeLayer(measureLineRef.current);
          }

          const line = L.polyline(updated, {
            color: '#d96b27',
            weight: 3,
            dashArray: '5, 8',
          }).addTo(map);

          measureLineRef.current = line;
        }
      }
    };

    map.on('click', handleMapClick);

    return () => {
      map.off('click', handleMapClick);
    };
  }, [measureMode, measurePoints]);

  const toggleMeasureMode = () => {
    if (measureMode) {
      setMeasureMode(false);
      setMeasurePoints([]);
      setMeasureDistance(null);
      if (measureLineRef.current && mapInstanceRef.current) {
        mapInstanceRef.current.removeLayer(measureLineRef.current);
        measureLineRef.current = null;
      }
    } else {
      setMeasureMode(true);
      setMeasurePoints([]);
      setMeasureDistance(null);
    }
  };

  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      alert('خدمة تحديد الموقع الجغرافي غير مدعومة على هذا الجهاز.');
      return;
    }

    setIsLocating(true);
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setIsLocating(false);
        const { latitude, longitude } = position.coords;

        const map = mapInstanceRef.current;
        if (!map) return;

        if (userMarkerRef.current) {
          map.removeLayer(userMarkerRef.current);
        }

        const marker = L.circleMarker([latitude, longitude], {
          radius: 8,
          fillColor: '#d96b27',
          color: '#ffffff',
          weight: 3,
          opacity: 1,
          fillOpacity: 1,
        }).addTo(map);

        userMarkerRef.current = marker;

        map.flyTo([latitude, longitude], 17, { duration: 1.5 });
      },
      (error) => {
        setIsLocating(false);
        const defaultPlan = DEMO_PLANS[0];
        if (mapInstanceRef.current) {
          mapInstanceRef.current.flyTo([defaultPlan.center.lat, defaultPlan.center.lng], 16);
        }
      },
      { timeout: 10000, enableHighAccuracy: true }
    );
  };

  const handleZoomIn = () => {
    mapInstanceRef.current?.zoomIn();
  };

  const handleZoomOut = () => {
    mapInstanceRef.current?.zoomOut();
  };

  const handleRecenter = () => {
    mapInstanceRef.current?.flyTo([24.8465, 46.6852], 16, { duration: 1 });
  };

  return (
    <div className="relative w-full h-[calc(100vh-3.5rem-4rem)] overflow-hidden bg-slate-100 dark:bg-slate-900">
      <div ref={mapContainerRef} className="w-full h-full z-0" />

      {tileError && (
        <div className="absolute top-3 left-4 right-4 z-20 bg-amber-500/90 text-white text-xs px-3 py-2 rounded-xl backdrop-blur-sm shadow-md flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>الخرائط تعمل في وضع التخزين المؤقت المحلي. تعذر تحميل بعض شرائح الخريطة من الإنترنت.</span>
        </div>
      )}

      {measureMode && (
        <div className="absolute top-3 left-4 right-4 z-20 bg-slate-900/90 text-white text-xs px-4 py-2.5 rounded-xl backdrop-blur-md shadow-lg flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Ruler className="w-4 h-4 text-amber-400" />
            <span>
              {measurePoints.length === 0 && 'انقر على الخريطة لتحديد النقطة الأولى'}
              {measurePoints.length === 1 && 'انقر لتحديد النقطة الثانية وقياس المسافة'}
              {measureDistance !== null && `المسافة المقاسة: ${measureDistance.toLocaleString()} متر`}
            </span>
          </div>
          <button
            onClick={toggleMeasureMode}
            className="text-amber-400 font-bold px-2 py-0.5 rounded hover:bg-slate-800"
          >
            إغلاق
          </button>
        </div>
      )}

      <div className="absolute top-4 right-4 z-10 flex flex-col gap-2">
        <button
          onClick={() => setShowLayerDrawer(!showLayerDrawer)}
          title="طبقات الخريطة"
          className="w-11 h-11 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
        >
          <Layers className="w-5 h-5" />
        </button>

        <button
          onClick={toggleMeasureMode}
          title="أداة قياس المسافات"
          className={`w-11 h-11 rounded-2xl shadow-lg border flex items-center justify-center transition-colors ${
            measureMode
              ? 'bg-[#d96b27] text-white border-transparent'
              : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-50'
          }`}
        >
          <Ruler className="w-5 h-5" />
        </button>

        <button
          onClick={handleLocateMe}
          title="موقعي الحالي"
          disabled={isLocating}
          className="w-11 h-11 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors"
        >
          <Crosshair className={`w-5 h-5 ${isLocating ? 'animate-spin text-[#d96b27]' : ''}`} />
        </button>

        <div className="flex flex-col bg-white dark:bg-slate-800 rounded-2xl shadow-lg border border-slate-200 dark:border-slate-700 overflow-hidden">
          <button
            onClick={handleZoomIn}
            title="تكبير"
            className="w-11 h-10 text-slate-700 dark:text-slate-200 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-700 border-b border-slate-200 dark:border-slate-700"
          >
            <Plus className="w-5 h-5" />
          </button>
          <button
            onClick={handleZoomOut}
            title="تصغير"
            className="w-11 h-10 text-slate-700 dark:text-slate-200 flex items-center justify-center hover:bg-slate-100 dark:hover:bg-slate-700"
          >
            <Minus className="w-5 h-5" />
          </button>
        </div>
      </div>

      {showLayerDrawer && (
        <div className="absolute top-16 right-4 z-20 w-64 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 p-4">
          <div className="flex items-center justify-between pb-2 mb-3 border-b border-slate-100 dark:border-slate-800">
            <span className="text-xs font-bold text-slate-800 dark:text-white font-cairo">
              طبقات وعرض الخريطة
            </span>
            <button
              onClick={() => setShowLayerDrawer(false)}
              className="text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              ✕
            </button>
          </div>

          <div className="space-y-1.5 mb-4">
            <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">
              نوع الخريطة الأساسية:
            </span>
            <div className="grid grid-cols-3 gap-1.5 text-xs">
              <button
                onClick={() => handleLayerSelect('streets')}
                className={`py-1.5 px-2 rounded-xl text-center border font-medium ${
                  activeLayer === 'streets'
                    ? 'bg-[#d96b27] text-white border-transparent'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                شوارع
              </button>
              <button
                onClick={() => handleLayerSelect('satellite')}
                className={`py-1.5 px-2 rounded-xl text-center border font-medium ${
                  activeLayer === 'satellite'
                    ? 'bg-[#d96b27] text-white border-transparent'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                قمر صناعي
              </button>
              <button
                onClick={() => handleLayerSelect('topo')}
                className={`py-1.5 px-2 rounded-xl text-center border font-medium ${
                  activeLayer === 'topo'
                    ? 'bg-[#d96b27] text-white border-transparent'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                }`}
              >
                هادئ
              </button>
            </div>
          </div>

          <div className="space-y-2 border-t border-slate-100 dark:border-slate-800 pt-3">
            <label className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
              <span>قطع الأراضي والمخططات</span>
              <input
                type="checkbox"
                checked={showParcels}
                onChange={(e) => setShowParcels(e.target.checked)}
                className="w-4 h-4 rounded text-[#d96b27] focus:ring-[#d96b27]"
              />
            </label>

            <label className="flex items-center justify-between text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
              <span>المرافق والخدمات العامة</span>
              <input
                type="checkbox"
                checked={showServices}
                onChange={(e) => setShowServices(e.target.checked)}
                className="w-4 h-4 rounded text-[#d96b27] focus:ring-[#d96b27]"
              />
            </label>
          </div>
        </div>
      )}

      <div className="absolute bottom-4 left-4 right-4 z-10 pointer-events-none">
        <div className="max-w-md mx-auto pointer-events-auto bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-3.5 py-2 rounded-2xl shadow-xl border border-slate-200/80 dark:border-slate-800 flex items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-1.5 truncate">
            <span className="w-2.5 h-2.5 rounded-full bg-[#d96b27] shrink-0" />
            <span className="font-semibold text-slate-800 dark:text-white truncate font-cairo">
              مخطط الواحة الحديث
            </span>
            <span className="text-slate-400 shrink-0">· حي النرجس</span>
          </div>

          <button
            onClick={handleRecenter}
            className="text-[11px] font-semibold text-[#d96b27] hover:underline shrink-0"
          >
            إعادة التوسيط
          </button>
        </div>
      </div>
    </div>
  );
};
