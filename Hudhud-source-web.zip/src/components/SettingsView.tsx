import React, { useState } from 'react';
import {
  Info,
  Shield,
  Download,
  Smartphone,
  MapPin,
  Database,
  Trash2,
  FileCode,
  Check,
  Globe,
  Copy,
  ExternalLink,
  QrCode,
} from 'lucide-react';

interface SettingsViewProps {
  onResetData: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ onResetData }) => {
  const [copiedPackage, setCopiedPackage] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  // Direct shared URL of the application
  const appUrl = 'https://ais-pre-g6lhkopviewmg3nz3iptlj-877479089986.europe-west2.run.app';
  const zipDownloadUrl = `${appUrl}/download/Hudhud-source.zip`;

  const copyPackageId = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText('com.hudhud.app');
      setCopiedPackage(true);
      setTimeout(() => setCopiedPackage(false), 2000);
    }
  };

  const copyDirectZipUrl = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(zipDownloadUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    }
  };

  const handleBlobDownload = async () => {
    try {
      setIsDownloading(true);
      const res = await fetch('/download/Hudhud-source.zip');
      if (!res.ok) throw new Error('فشل جلب الملف');
      const blob = await res.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = 'Hudhud-source.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (err) {
      // Fallback: open direct URL in new window/tab
      window.open(zipDownloadUrl, '_blank');
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-4 space-y-5 pb-12">
      {/* Brand Identity Card */}
      <div className="p-6 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-950 text-white rounded-3xl shadow-xl border border-slate-700/60 flex flex-col items-center text-center">
        <div className="w-24 h-24 rounded-2xl overflow-hidden border-2 border-amber-500/40 shadow-lg mb-3 bg-slate-800">
          <img
            src="/assets/aistudio/file_00000000cce081fab0c076663ac3d5ce_d4c551e0.jpg"
            alt="شعار هدهد"
            className="w-full h-full object-cover"
          />
        </div>

        <h2 className="text-2xl font-extrabold font-cairo">
          هُدْهُدْ <span className="text-amber-500 font-sans">Hudhud</span>
        </h2>
        <p className="text-xs text-slate-300 mt-1 max-w-sm">
          تطبيق الاستعلام الجغرافي الذكي للأراضي والمخططات الحضرية والخدمات الميدانية
        </p>

        <div className="mt-3 flex items-center gap-2">
          <span className="text-xs font-mono bg-slate-800/80 border border-slate-700 px-3 py-1 rounded-full text-amber-400">
            com.hudhud.app · v1.0.0
          </span>
          <button
            onClick={copyPackageId}
            className="text-[11px] text-slate-400 hover:text-white underline flex items-center gap-1"
          >
            {copiedPackage ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            <span>{copiedPackage ? 'تم النسخ!' : 'نسخ المعرف'}</span>
          </button>
        </div>
      </div>

      {/* Main Download & Mobile Installation Center */}
      <div className="p-5 bg-gradient-to-br from-orange-50 to-amber-50 dark:from-slate-800 dark:to-slate-900 rounded-3xl border-2 border-[#d96b27]/30 shadow-md space-y-4">
        <div className="flex items-center gap-2.5">
          <Smartphone className="w-6 h-6 text-[#d96b27]" />
          <div>
            <h3 className="text-base font-extrabold text-slate-900 dark:text-white font-cairo">
              تثبيت وتشغيل التطبيق على الهاتف
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              اختر الطريقة الأنسب لك لتشغيل التطبيق وتجربته فورياً
            </p>
          </div>
        </div>

        {/* Action 1: Direct File Download (Blob + External) */}
        <div className="p-4 bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200/80 dark:border-slate-700 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-bold text-xs text-slate-900 dark:text-white">
              <FileCode className="w-4 h-4 text-[#d96b27]" />
              <span>تحميل ملف حزمة المشروع (Hudhud-source.zip)</span>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 font-bold">
              جاهز للتحميل (~434 KB)
            </span>
          </div>

          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
            يحتوي على كافة ملفات تطبيق الأندرويد Capacitor مع الشعار الرسمي المعتمد، والأذونات وملف AndroidManifest.xml.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
            <button
              onClick={handleBlobDownload}
              disabled={isDownloading}
              className="h-12 px-4 rounded-xl bg-[#d96b27] hover:bg-[#c35a1a] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] transition-all"
            >
              <Download className="w-4 h-4" />
              <span>{isDownloading ? 'جارٍ بدء التحميل...' : 'تنزيل الملف المباشر (ZIP)'}</span>
            </button>

            <a
              href={zipDownloadUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="h-12 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm active:scale-[0.98] transition-all"
            >
              <ExternalLink className="w-4 h-4 text-amber-400" />
              <span>فتح الرابط في نافذة مستقلة</span>
            </a>
          </div>

          {/* Copy direct link */}
          <div className="pt-2 flex items-center justify-between text-[11px] text-slate-500 bg-slate-50 dark:bg-slate-900/60 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
            <span className="font-mono truncate max-w-[280px]" dir="ltr">
              {zipDownloadUrl}
            </span>
            <button
              onClick={copyDirectZipUrl}
              className="text-[#d96b27] hover:underline font-bold shrink-0 flex items-center gap-1 mr-2"
            >
              {copiedUrl ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedUrl ? 'تم النسخ!' : 'نسخ الرابط'}</span>
            </button>
          </div>
        </div>

        {/* Action 2: Instant PWA Install on Mobile */}
        <div className="p-4 bg-white dark:bg-slate-800/90 rounded-2xl border border-slate-200/80 dark:border-slate-700 space-y-2">
          <div className="flex items-center gap-2 font-bold text-xs text-slate-900 dark:text-white">
            <Globe className="w-4 h-4 text-blue-500" />
            <span>التثبيت المباشر على الهاتف دون الحاجة لأدوات إضافية:</span>
          </div>

          <ol className="text-xs text-slate-600 dark:text-slate-300 space-y-1.5 list-decimal list-inside pr-1">
            <li>افتح الرابط المباشر على متصفح Chrome بهاتفك:
              <a
                href={appUrl}
                target="_blank"
                rel="noreferrer"
                className="block font-mono text-[11px] text-blue-600 dark:text-blue-400 underline mt-0.5"
                dir="ltr"
              >
                {appUrl}
              </a>
            </li>
            <li>اضغط على خيارات المتصفح (الثلاث نقاط ⋮).</li>
            <li>اختر <strong>«تثبيت التطبيق» (Install app)</strong> أو <strong>«إضافة إلى الشاشة الرئيسية»</strong>.</li>
            <li>سيتم تثبيت التطبيق فوراً بشعار هُدهُد واسمه الكامل ويعمل بتجربة تطبيق أندرويد حقيقية بملء الشاشة.</li>
          </ol>
        </div>
      </div>

      {/* Permissions and GPS */}
      <div className="p-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700 shadow-xs space-y-3">
        <div className="flex items-center gap-2">
          <Shield className="w-4 h-4 text-[#d96b27]" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white font-cairo">
            أذونات التطبيق والخصوصية
          </h3>
        </div>

        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-900">
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-500" />
              <div>
                <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                  الموقع الجغرافي (GPS)
                </span>
                <span className="text-[11px] text-slate-400">
                  تحديد المسافة إلى الخدمات وحساب إحداثيات البلاغات
                </span>
              </div>
            </div>
            <span className="font-bold text-emerald-600 dark:text-emerald-400 text-[11px]">
              مفعل
            </span>
          </div>

          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 dark:bg-slate-900">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-500" />
              <div>
                <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                  التخزين المحلي (Offline Storage)
                </span>
                <span className="text-[11px] text-slate-400">
                  حفظ المسودات والمفضلات والعمل بدون اتصال بالإنترنت
                </span>
              </div>
            </div>
            <span className="font-bold text-blue-600 dark:text-blue-400 text-[11px]">
              نشط
            </span>
          </div>
        </div>
      </div>

      {/* Data Source & Municipal Disclaimer */}
      <div className="p-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700 shadow-xs space-y-2">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-slate-500" />
          <h3 className="text-sm font-bold text-slate-900 dark:text-white font-cairo">
            إخلاء المسؤولية ومصدر البيانات
          </h3>
        </div>
        <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
          تعتبر جميع السجلات وقطع الأراضي والمخططات المعروضة في هذا الإصدار «بيانات تجريبية» لأغراض العرض واختبار الأنظمة الجغرافية والتطبيقات الميدانية. لا تعتبر هذه البيانات وثائق ملكية رسمية أو قرارات مساحية نهائية.
        </p>
      </div>

      {/* Clear Cache / Reset Demo Data */}
      <div className="p-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700 shadow-xs flex items-center justify-between">
        <div>
          <span className="text-xs font-bold text-slate-900 dark:text-white block">
            إعادة ضبط الذاكرة المؤقتة
          </span>
          <span className="text-[11px] text-slate-400">
            مسح المسودات المحلية وسجلات المفضلة
          </span>
        </div>
        <button
          onClick={onResetData}
          className="px-3.5 py-2 rounded-xl text-xs font-medium text-red-600 dark:text-red-400 bg-red-50 dark:bg-red-950/30 hover:bg-red-100 transition-colors flex items-center gap-1.5"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>مسح</span>
        </button>
      </div>
    </div>
  );
};
