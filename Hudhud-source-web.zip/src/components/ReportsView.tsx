import React, { useState, useEffect } from 'react';
import {
  AlertTriangle,
  Camera,
  MapPin,
  CheckCircle,
  Clock,
  Trash2,
  Send,
  Upload,
} from 'lucide-react';
import { GeoReport, LatLng } from '../types/gis';
import { gisApi } from '../services/gisApi';
import { storage } from '../services/storage';

interface ReportsViewProps {
  userLocation: LatLng | null;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ userLocation }) => {
  const [category, setCategory] = useState<GeoReport['category']>('تعديات على أراضي عامة');
  const [description, setDescription] = useState('');
  const [customLat, setCustomLat] = useState(userLocation ? userLocation.lat.toString() : '24.8465');
  const [customLng, setCustomLng] = useState(userLocation ? userLocation.lng.toString() : '46.6852');
  const [photoPreview, setPhotoPreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ message: string; type: 'success' | 'info' } | null>(null);
  const [draftReports, setDraftReports] = useState<GeoReport[]>([]);

  useEffect(() => {
    setDraftReports(storage.getDraftReports());
  }, []);

  useEffect(() => {
    if (userLocation) {
      setCustomLat(userLocation.lat.toFixed(5));
      setCustomLng(userLocation.lng.toFixed(5));
    }
  }, [userLocation]);

  const handleUseCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setCustomLat(pos.coords.latitude.toFixed(5));
          setCustomLng(pos.coords.longitude.toFixed(5));
          showToast('تم التقاط إحداثيات موقعك الجغرافي بنجاح', 'success');
        },
        () => {
          showToast('تعذر جلب الموقع. يرجى تفعيل إذن الموقع', 'info');
        }
      );
    }
  };

  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const showToast = (message: string, type: 'success' | 'info') => {
    setNotification({ message, type });
    setTimeout(() => setNotification(null), 4000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!description.trim()) {
      showToast('يرجى كتابة وصف تفصيلي للبلاغ', 'info');
      return;
    }

    setSubmitting(true);

    const lat = parseFloat(customLat) || 24.8465;
    const lng = parseFloat(customLng) || 46.6852;

    const result = await gisApi.submitGeoReport({
      category,
      description: description.trim(),
      coordinates: { lat, lng },
      photoUrl: photoPreview || undefined,
      addressApprox: 'حي النرجس، الرياض (تحديد ميداني)',
    });

    setSubmitting(false);

    setDraftReports(storage.getDraftReports());

    setDescription('');
    setPhotoPreview(null);

    showToast(result.messageAr, 'info');
  };

  const handleDeleteDraft = (id: string) => {
    storage.deleteDraftReport(id);
    setDraftReports(storage.getDraftReports());
    showToast('تم حذف المسودة المحلية', 'info');
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-4 space-y-5">
      {notification && (
        <div className="p-3 rounded-2xl bg-slate-900 text-white text-xs font-medium shadow-xl flex items-center gap-2 border border-slate-700 animate-slideDown">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notification.message}</span>
        </div>
      )}

      <div className="p-4 rounded-3xl bg-white dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 shadow-xs space-y-1">
        <h2 className="text-lg font-bold text-slate-900 dark:text-white font-cairo flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-[#d96b27]" />
          <span>البلاغات والملاحظات الجغرافية الميدانية</span>
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
          سجل الملاحظات والتعديات الميدانية مع الإحداثيات والصور. في وضع عدم الاتصال، يتم حفظ البلاغات كمسودات محلية في جهازك لحين الاتصال بالخادم البلدي المعتمد.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="p-5 bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700 shadow-xs space-y-4">
        <h3 className="text-sm font-bold text-slate-900 dark:text-white font-cairo">
          إنشاء بلاغ ميداني جديد
        </h3>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            تصنيف البلاغ:
          </label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value as any)}
            className="w-full h-11 px-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white font-cairo focus:outline-hidden focus:ring-2 focus:ring-[#d96b27]"
          >
            <option value="تعديات على أراضي عامة">تعديات على أراضي عامة أو مرافق</option>
            <option value="صيانة طرق ومرافق">هبوط أسفلت أو صيانة طرق</option>
            <option value="نقص لوحات إرشادية">نقص لوحات تسمية الشوارع وأرقام الأراضي</option>
            <option value="تصريف سيول ومياه أمطار">تجمع مياه أمطار وتصريف سيول</option>
            <option value="نظافة وتراكم مخلفات">تراكم مخلفات بناء ونظافة</option>
            <option value="أخرى">أخرى (ملاحظة عامة)</option>
          </select>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300">
            وصف الحالة أو الملاحظة:
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            placeholder="اكتب تفاصيل البلاغ، معالم الموقع، أو رقم القطعة المجاورة..."
            className="w-full p-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl text-xs text-slate-900 dark:text-white font-cairo placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-[#d96b27]"
            required
          />
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-[#d96b27]" />
              <span>إحداثيات الموقع الميداني:</span>
            </label>
            <button
              type="button"
              onClick={handleUseCurrentLocation}
              className="text-[11px] font-semibold text-[#d96b27] hover:underline"
            >
              التقاط موقعي الحالي
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 font-mono text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block mb-0.5">خط العرض (Lat):</span>
              <input
                type="text"
                value={customLat}
                onChange={(e) => setCustomLat(e.target.value)}
                className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
            <div>
              <span className="text-[10px] text-slate-400 block mb-0.5">خط الطول (Lng):</span>
              <input
                type="text"
                value={customLng}
                onChange={(e) => setCustomLng(e.target.value)}
                className="w-full h-10 px-3 bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl"
              />
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Camera className="w-3.5 h-3.5 text-[#d96b27]" />
            <span>إرفاق صورة للموقع (اختياري):</span>
          </label>

          {photoPreview ? (
            <div className="relative w-full h-40 rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700">
              <img src={photoPreview} alt="معاينة الصورة" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => setPhotoPreview(null)}
                className="absolute top-2 right-2 px-2.5 py-1 bg-black/70 text-white rounded-lg text-xs"
              >
                إلغاء الصورة
              </button>
            </div>
          ) : (
            <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-2xl cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-900 transition-colors">
              <div className="flex flex-col items-center justify-center pt-2 pb-3">
                <Upload className="w-6 h-6 text-slate-400 mb-1" />
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  انقر لاختيار صورة من الكاميرا أو المعرض
                </p>
              </div>
              <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
            </label>
          )}
        </div>

        <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-900/80 border border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-500 shrink-0" />
          <span>
            تنبيه: يتم حفظ البلاغ محلياً كمسودة ميدانية في ذاكرة التطبيق نظراً لعدم ربط خادم بلدي مباشر.
          </span>
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full h-12 rounded-xl bg-[#d96b27] text-white font-bold text-sm shadow-md hover:bg-[#c45a1c] active:scale-[0.98] transition-all flex items-center justify-center gap-2 font-cairo"
        >
          <Send className="w-4 h-4" />
          <span>{submitting ? 'جارٍ الحفظ...' : 'حفظ البلاغ في المسودات المحلية'}</span>
        </button>
      </form>

      <div className="space-y-3 pt-2">
        <div className="flex items-center justify-between px-1">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white font-cairo">
            المسودات الميدانية المحفوظة محلياً ({draftReports.length})
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">حفظ دائم بالجهاز</span>
        </div>

        {draftReports.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700">
            <p className="text-xs text-slate-500 dark:text-slate-400">
              لا توجد بلاغات محفوظة كمسودة حتى الآن.
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {draftReports.map((draft) => (
              <div
                key={draft.id}
                className="p-3.5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs flex items-start justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900 dark:text-white font-cairo">
                      {draft.category}
                    </span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-700 dark:text-amber-400">
                      مسودة محلية
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-normal line-clamp-2">
                    {draft.description}
                  </p>
                  <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                    <span>
                      {draft.coordinates.lat.toFixed(4)}, {draft.coordinates.lng.toFixed(4)}
                    </span>
                    <span>·</span>
                    <span>{new Date(draft.createdAt).toLocaleDateString('ar-SA')}</span>
                  </div>
                </div>

                <button
                  onClick={() => handleDeleteDraft(draft.id)}
                  title="حذف المسودة"
                  className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-xl text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors shrink-0"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
