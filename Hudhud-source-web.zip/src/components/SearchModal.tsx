import React, { useState } from 'react';
import { Search, Building, Building2, X, ArrowUpRight } from 'lucide-react';
import { Parcel, PublicService, SubdivisionPlan } from '../types/gis';
import { DEMO_PARCELS, DEMO_PLANS, DEMO_PUBLIC_SERVICES } from '../data/mockGisData';

interface SearchModalProps {
  onSelectParcel: (parcel: Parcel) => void;
  onSelectService: (service: PublicService) => void;
  onSelectPlan: (plan: SubdivisionPlan) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  onSelectParcel,
  onSelectService,
  onSelectPlan,
}) => {
  const [query, setQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'parcels' | 'plans' | 'services'>('all');

  const trimmed = query.trim().toLowerCase();

  const filteredParcels = DEMO_PARCELS.filter(
    (p) =>
      !trimmed ||
      p.parcelNumber.toLowerCase().includes(trimmed) ||
      p.planNumber.toLowerCase().includes(trimmed) ||
      p.planName.toLowerCase().includes(trimmed) ||
      p.landUse.toLowerCase().includes(trimmed)
  );

  const filteredPlans = DEMO_PLANS.filter(
    (pl) =>
      !trimmed ||
      pl.planNumber.toLowerCase().includes(trimmed) ||
      pl.planName.toLowerCase().includes(trimmed) ||
      pl.district.toLowerCase().includes(trimmed) ||
      pl.city.toLowerCase().includes(trimmed)
  );

  const filteredServices = DEMO_PUBLIC_SERVICES.filter(
    (s) =>
      !trimmed ||
      s.name.toLowerCase().includes(trimmed) ||
      s.categoryLabelAr.toLowerCase().includes(trimmed) ||
      s.address.toLowerCase().includes(trimmed)
  );

  const hasResults =
    (filterType === 'all' || filterType === 'parcels' ? filteredParcels.length : 0) +
    (filterType === 'all' || filterType === 'plans' ? filteredPlans.length : 0) +
    (filterType === 'all' || filterType === 'services' ? filteredServices.length : 0) > 0;

  return (
    <div className="w-full max-w-2xl mx-auto p-4 space-y-4">
      {/* Search Input Bar */}
      <div className="relative">
        <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 pointer-events-none" />
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث برقم القطعة، المخطط، اسم الخدمة، أو الحي..."
          className="w-full h-12 pr-11 pl-10 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-2xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-hidden focus:ring-2 focus:ring-[#d96b27] shadow-xs font-cairo"
          autoFocus
        />
        {query && (
          <button
            onClick={() => setQuery('')}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <button
          onClick={() => setFilterType('all')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-colors whitespace-nowrap ${
            filterType === 'all'
              ? 'bg-[#d96b27] text-white shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          الكل
        </button>
        <button
          onClick={() => setFilterType('parcels')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-colors whitespace-nowrap ${
            filterType === 'parcels'
              ? 'bg-[#d96b27] text-white shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          قطع الأراضي ({filteredParcels.length})
        </button>
        <button
          onClick={() => setFilterType('plans')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-colors whitespace-nowrap ${
            filterType === 'plans'
              ? 'bg-[#d96b27] text-white shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          المخططات ({filteredPlans.length})
        </button>
        <button
          onClick={() => setFilterType('services')}
          className={`px-3 py-1.5 rounded-xl font-medium transition-colors whitespace-nowrap ${
            filterType === 'services'
              ? 'bg-[#d96b27] text-white shadow-xs'
              : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
          }`}
        >
          الخدمات العامة ({filteredServices.length})
        </button>
      </div>

      {!query && (
        <div className="bg-white dark:bg-slate-800/80 p-4 rounded-2xl border border-slate-200/80 dark:border-slate-800">
          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400 block mb-2">
            عمليات بحث شائعة:
          </span>
          <div className="flex flex-wrap gap-2 text-xs">
            {['1042', 'م/1442/105', 'مستشفى الملك فهد', 'حي النرجس', 'مخطط الواحة'].map((tag) => (
              <button
                key={tag}
                onClick={() => setQuery(tag)}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-colors"
              >
                {tag}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Results List */}
      <div className="space-y-3">
        {(filterType === 'all' || filterType === 'parcels') && filteredParcels.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 px-1">
              قطع الأراضي ({filteredParcels.length})
            </h3>
            {filteredParcels.map((parcel) => (
              <div
                key={parcel.id}
                onClick={() => onSelectParcel(parcel)}
                className="p-3.5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:border-[#d96b27] transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-orange-500/10 text-[#d96b27] flex items-center justify-center font-bold text-sm shrink-0">
                    {parcel.parcelNumber}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold text-slate-900 dark:text-white font-cairo">
                        قطعة رقم {parcel.parcelNumber}
                      </span>
                      <span className="text-[11px] text-slate-500">· {parcel.landUse}</span>
                    </div>
                    <span className="text-xs text-slate-500 dark:text-slate-400 block">
                      {parcel.planName} · {parcel.areaSquareMeters} م²
                    </span>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-[#d96b27] transition-colors" />
              </div>
            ))}
          </div>
        )}

        {(filterType === 'all' || filterType === 'plans') && filteredPlans.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 px-1">
              المخططات المعتمدة ({filteredPlans.length})
            </h3>
            {filteredPlans.map((plan) => (
              <div
                key={plan.id}
                onClick={() => onSelectPlan(plan)}
                className="p-3.5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:border-[#d96b27] transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0">
                    <Building className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-slate-900 dark:text-white block font-cairo">
                      {plan.planName}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400 block">
                      رقم {plan.planNumber} · {plan.district} · {plan.totalParcels} قطعة
                    </span>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-[#d96b27] transition-colors" />
              </div>
            ))}
          </div>
        )}

        {(filterType === 'all' || filterType === 'services') && filteredServices.length > 0 && (
          <div className="space-y-2">
            <h3 className="text-xs font-bold text-slate-500 dark:text-slate-400 px-1">
              المرافق والخدمات العامة ({filteredServices.length})
            </h3>
            {filteredServices.map((service) => (
              <div
                key={service.id}
                onClick={() => onSelectService(service)}
                className="p-3.5 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700/80 shadow-xs hover:border-[#d96b27] transition-all cursor-pointer flex items-center justify-between group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="text-sm font-bold text-slate-900 dark:text-white block font-cairo">
                      {service.name}
                    </span>
                    <span className="text-xs text-slate-500 dark:text-slate-400 block">
                      {service.categoryLabelAr} · {service.address}
                    </span>
                  </div>
                </div>
                <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-[#d96b27] transition-colors" />
              </div>
            ))}
          </div>
        )}

        {!hasResults && (
          <div className="text-center py-12 px-4">
            <div className="w-16 h-16 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto mb-3 text-slate-400">
              <Search className="w-8 h-8" />
            </div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200 mb-1">
              لا توجد نتائج مطابقة
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
              تأكد من صحة رقم القطعة أو اسم المخطط، أو جرّب البحث بكلمات عامة مثل «سكني» أو «النرجس».
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
