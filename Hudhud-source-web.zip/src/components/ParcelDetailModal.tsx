import React, { useState, useEffect } from 'react';
import {
  X,
  MapPin,
  Bookmark,
  Navigation,
  Share2,
  Check,
  Building,
  Ruler,
  Calendar,
  ShieldAlert,
} from 'lucide-react';
import { Parcel } from '../types/gis';
import { storage } from '../services/storage';

interface ParcelDetailModalProps {
  parcel: Parcel | null;
  onClose: () => void;
}

export const ParcelDetailModal: React.FC<ParcelDetailModalProps> = ({ parcel, onClose }) => {
  const [isFav, setIsFav] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (parcel) {
      setIsFav(storage.isFavorite(parcel.id));
      setCopied(false);
    }
  }, [parcel]);

  if (!parcel) return null;

  const toggleFavorite = () => {
    if (isFav) {
      storage.removeFavorite(parcel.id);
      setIsFav(false);
    } else {
      storage.addFavorite({
        id: parcel.id,
        type: 'parcel',
        title: `قطعة رقم ${parcel.parcelNumber}`,
        subtitle: `${parcel.planName} · ${parcel.landUse}`,
        coordinates: parcel.coordinates,
        savedAt: new Date().toISOString(),
        data: parcel,
      });
      setIsFav(true);
    }
  };

  const openGoogleMaps = () => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${parcel.coordinates.lat},${parcel.coordinates.lng}`;
    window.open(url, '_blank');
  };

  const handleShare = () => {
    const text = `بيانات قطعة أرض رقم ${parcel.parcelNumber} - ${parcel.planName}\nالمساحة: ${parcel.areaSquareMeters} م²\nالإحداثيات: ${parcel.coordinates.lat}, ${parcel.coordinates.lng}`;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  let badgeColor = 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300';
  if (parcel.landUse === 'تجاري') badgeColor = 'bg-orange-50 text-orange-700 dark:bg-orange-950/40 dark:text-orange-300';
  if (parcel.landUse === 'تعليمي') badgeColor = 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300';
  if (parcel.landUse === 'حدائق ومرافق') badgeColor = 'bg-green-50 text-green-700 dark:bg-green-950/40 dark:text-green-300';
  if (parcel.landUse === 'استثماري') badgeColor = 'bg-purple-50 text-purple-700 dark:bg-purple-950/40 dark:text-purple-300';

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-t-3xl sm:rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[88vh] overflow-y-auto pb-safe">
        <div className="sm:hidden pt-3 pb-1 flex justify-center">
          <div className="w-12 h-1.5 rounded-full bg-slate-300 dark:bg-slate-700" />
        </div>

        <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 text-[#d96b27] flex items-center justify-center font-bold text-lg shrink-0">
              {parcel.parcelNumber}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold text-slate-900 dark:text-white font-cairo">
                  قطعة رقم {parcel.parcelNumber}
                </h2>
                <span className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full ${badgeColor}`}>
                  {parcel.landUse}
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                {parcel.planName} · مخطط رقم {parcel.planNumber}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="min-h-[40px] min-w-[40px] flex items-center justify-center rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="mx-4 sm:mx-6 mt-4 p-3 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-800/50 flex items-start gap-2.5 text-xs text-amber-900 dark:text-amber-200">
          <ShieldAlert className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400 mt-0.5" />
          <div>
            <span className="font-bold">سجل تجريبي (بيانات تجريبية):</span>
            <span className="block text-[11px] text-amber-800 dark:text-amber-300/80 mt-0.5">
              هذه المعلومات معروضة لأغراض اختبار نظام هُدهُد وتطوير الواجهات الجغرافية، وليست مستنداً رسمياً للملكية العقارية.
            </span>
          </div>
        </div>

        <div className="p-4 sm:p-6 space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">
                المساحة الإجمالية
              </span>
              <span className="text-xl font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                {parcel.areaSquareMeters.toLocaleString()}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400 mr-1">م²</span>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <span className="text-[11px] text-slate-500 dark:text-slate-400 block mb-1">
                حالة الاعتماد
              </span>
              <span className="text-sm font-bold text-emerald-600 dark:text-emerald-400 block truncate">
                {parcel.status}
              </span>
            </div>
          </div>

          {parcel.dimensions && (
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 mb-2 text-xs font-bold text-slate-700 dark:text-slate-300">
                <Ruler className="w-4 h-4 text-[#d96b27]" />
                <span>أطوال الأضلاع (متر):</span>
              </div>
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 block">شمالاً</span>
                  <span className="font-bold text-slate-800 dark:text-slate-100 font-mono">
                    {parcel.dimensions.north}م
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 block">جنوباً</span>
                  <span className="font-bold text-slate-800 dark:text-slate-100 font-mono">
                    {parcel.dimensions.south}م
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 block">شرقاً</span>
                  <span className="font-bold text-slate-800 dark:text-slate-100 font-mono">
                    {parcel.dimensions.east}م
                  </span>
                </div>
                <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-700">
                  <span className="text-[10px] text-slate-400 block">غرباً</span>
                  <span className="font-bold text-slate-800 dark:text-slate-100 font-mono">
                    {parcel.dimensions.west}م
                  </span>
                </div>
              </div>
            </div>
          )}

          {parcel.zoningDetails && (
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-100 dark:border-slate-800 space-y-2 text-xs">
              <div className="flex items-center gap-2 font-bold text-slate-700 dark:text-slate-300">
                <Building className="w-4 h-4 text-[#d96b27]" />
                <span>اشتراطات البناء والتنظيم:</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/40 dark:border-slate-700/40">
                <span className="text-slate-500">نسبة البناء المسموحة:</span>
                <span className="font-bold font-mono">{parcel.zoningDetails.buildingPercentage}%</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-200/40 dark:border-slate-700/40">
                <span className="text-slate-500">أقصى عدد أدوار:</span>
                <span className="font-bold">{parcel.zoningDetails.floorsAllowed} أدوار</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-500">الارتدادات النظامية:</span>
                <span className="font-bold">{parcel.zoningDetails.setbacks}</span>
              </div>
            </div>
          )}

          <div className="space-y-1.5 text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#d96b27]" />
                <span>الإحداثيات المركزية:</span>
              </span>
              <span className="font-mono text-slate-800 dark:text-slate-200">
                {parcel.coordinates.lat.toFixed(5)}, {parcel.coordinates.lng.toFixed(5)}
              </span>
            </div>

            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>تاريخ آخر تحديث:</span>
              </span>
              <span>{parcel.updatedAt}</span>
            </div>
          </div>

          <div className="pt-2 grid grid-cols-3 gap-2">
            <button
              onClick={toggleFavorite}
              className={`min-h-[46px] rounded-xl flex items-center justify-center gap-1.5 text-xs font-bold border transition-colors ${
                isFav
                  ? 'bg-amber-500 text-white border-amber-600'
                  : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
              }`}
            >
              <Bookmark className={`w-4 h-4 ${isFav ? 'fill-white' : ''}`} />
              <span>{isFav ? 'في المفضلة' : 'حفظ'}</span>
            </button>

            <button
              onClick={openGoogleMaps}
              className="min-h-[46px] rounded-xl bg-[#d96b27] text-white flex items-center justify-center gap-1.5 text-xs font-bold shadow-md hover:bg-[#c45a1c] transition-colors"
            >
              <Navigation className="w-4 h-4" />
              <span>ملاحة Maps</span>
            </button>

            <button
              onClick={handleShare}
              className="min-h-[46px] rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 flex items-center justify-center gap-1.5 text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Share2 className="w-4 h-4" />}
              <span>{copied ? 'تم النسخ' : 'مشاركة'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
