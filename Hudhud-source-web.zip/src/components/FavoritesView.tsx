import React, { useState, useEffect } from 'react';
import { Bookmark, MapPin, Trash2, Building2, Layers } from 'lucide-react';
import { FavoriteItem, Parcel, PublicService } from '../types/gis';
import { storage } from '../services/storage';

interface FavoritesViewProps {
  onSelectParcel: (parcel: Parcel) => void;
  onSelectService: (service: PublicService) => void;
  onShowOnMap: (coords: { lat: number; lng: number }) => void;
}

export const FavoritesView: React.FC<FavoritesViewProps> = ({
  onSelectParcel,
  onSelectService,
  onShowOnMap,
}) => {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);

  useEffect(() => {
    setFavorites(storage.getFavorites());
  }, []);

  const handleRemove = (id: string) => {
    storage.removeFavorite(id);
    setFavorites(storage.getFavorites());
  };

  return (
    <div className="w-full max-w-2xl mx-auto p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-slate-900 dark:text-white font-cairo flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-[#d96b27] fill-[#d96b27]" />
            <span>العناصر المحفوظة والمفضلة</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            قطع الأراضي والمرافق المحفوظة محلياً للوصول السريع
          </p>
        </div>

        <span className="text-xs font-mono font-bold text-slate-500 bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded-lg">
          {favorites.length} عنصر
        </span>
      </div>

      {favorites.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-800 rounded-3xl border border-slate-200/80 dark:border-slate-700 space-y-2">
          <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-700/60 flex items-center justify-center mx-auto text-slate-400">
            <Bookmark className="w-7 h-7" />
          </div>
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            قائمتك المفضلة فارغة
          </h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 max-w-xs mx-auto">
            يمكنك حفظ أي قطعة أرض أو مرفق بالضغط على أيقونة المفضلة للرجوع إليها في أي وقت دون اتصال.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {favorites.map((fav) => (
            <div
              key={fav.id}
              className="p-4 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200/80 dark:border-slate-700 shadow-xs flex items-center justify-between gap-3 group"
            >
              <div
                onClick={() => {
                  if (fav.type === 'parcel') onSelectParcel(fav.data as Parcel);
                  else if (fav.type === 'service') onSelectService(fav.data as PublicService);
                  else onShowOnMap(fav.coordinates);
                }}
                className="flex items-center gap-3 cursor-pointer flex-1"
              >
                <div className="w-11 h-11 rounded-xl bg-orange-500/10 text-[#d96b27] flex items-center justify-center shrink-0">
                  {fav.type === 'parcel' ? <Layers className="w-5 h-5" /> : <Building2 className="w-5 h-5" />}
                </div>

                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white font-cairo group-hover:text-[#d96b27] transition-colors">
                    {fav.title}
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    {fav.subtitle}
                  </p>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {fav.coordinates.lat.toFixed(4)}, {fav.coordinates.lng.toFixed(4)}
                  </span>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => onShowOnMap(fav.coordinates)}
                  title="عرض بالخريطة"
                  className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition-colors"
                >
                  <MapPin className="w-4 h-4 text-[#d96b27]" />
                </button>

                <button
                  onClick={() => handleRemove(fav.id)}
                  title="إزالة من المفضلة"
                  className="min-h-[38px] min-w-[38px] flex items-center justify-center rounded-xl text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
