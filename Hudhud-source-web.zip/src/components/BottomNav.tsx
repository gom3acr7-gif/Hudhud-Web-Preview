import React from 'react';
import { Map, Search, Building2, AlertTriangle, Bookmark } from 'lucide-react';

export type NavTab = 'map' | 'search' | 'services' | 'reports' | 'favorites';

interface BottomNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, onTabChange }) => {
  const tabs = [
    { id: 'map' as NavTab, label: 'الخريطة', icon: Map },
    { id: 'search' as NavTab, label: 'البحث', icon: Search },
    { id: 'services' as NavTab, label: 'الخدمات', icon: Building2 },
    { id: 'reports' as NavTab, label: 'البلاغات', icon: AlertTriangle },
    { id: 'favorites' as NavTab, label: 'المفضلة', icon: Bookmark },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 pb-safe">
      <div className="grid grid-cols-5 h-16 items-center max-w-lg mx-auto">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => onTabChange(tab.id)}
              className={`min-h-[44px] flex flex-col items-center justify-center transition-colors relative ${
                isActive
                  ? 'text-[#d96b27] dark:text-[#f59e0b]'
                  : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-110' : ''}`} />
              <span className={`text-[11px] font-medium tracking-tight mt-1 ${isActive ? 'font-bold' : ''}`}>
                {tab.label}
              </span>
              {isActive && (
                <span className="absolute top-1 w-1 h-1 rounded-full bg-[#d96b27] dark:bg-[#f59e0b]" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
};
