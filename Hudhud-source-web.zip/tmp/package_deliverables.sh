#!/bin/bash
set -e

APK_SRC="android/app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK_SRC" ]; then
  echo "SUCCESS: APK build found at $APK_SRC"
  mkdir -p public/download dist/download
  cp "$APK_SRC" public/download/Hudhud.apk
  cp "$APK_SRC" dist/download/Hudhud.apk
  echo "Copied APK to public/download/Hudhud.apk and dist/download/Hudhud.apk"
  
  ls -lh public/download/Hudhud.apk
  sha256sum public/download/Hudhud.apk
else
  echo "WARNING: APK file not found at $APK_SRC"
fi

echo "Creating complete project source ZIP..."
mkdir -p public/download dist/download
zip -r -q /tmp/Hudhud-source.zip . \
  -x "node_modules/*" \
  -x ".git/*" \
  -x "android/.gradle/*" \
  -x "android/app/build/*" \
  -x ".aistudio/*" \
  -x "public/download/Hudhud-source.zip" \
  -x "dist/download/Hudhud-source.zip"

cp /tmp/Hudhud-source.zip public/download/Hudhud-source.zip
cp /tmp/Hudhud-source.zip dist/download/Hudhud-source.zip

echo "ZIP created successfully at public/download/Hudhud-source.zip"
ls -lh public/download/Hudhud-source.zip
