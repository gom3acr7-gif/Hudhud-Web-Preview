import os
import zipfile
import shutil

output_path = 'public/download/Hudhud-source.zip'
os.makedirs('public/download', exist_ok=True)
os.makedirs('dist/download', exist_ok=True)

excluded_prefixes = (
    './node_modules',
    './dist',
    './.git',
    './.jdk21',
    './.android-sdk',
    './android/.gradle',
    './android/app/build',
    './.aistudio',
    './public/download',
)

with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        rel_root = root
        if any(rel_root == prefix or rel_root.startswith(prefix + '/') or rel_root.startswith(prefix + '\\') for prefix in excluded_prefixes):
            continue
        for file in files:
            file_path = os.path.join(root, file)
            if any(file_path.startswith(prefix) for prefix in excluded_prefixes):
                continue
            archive_name = os.path.relpath(file_path, '.')
            zipf.write(file_path, archive_name)

shutil.copyfile(output_path, 'dist/download/Hudhud-source.zip')
print('ZIP created successfully! Size:', os.path.getsize(output_path), 'bytes')
